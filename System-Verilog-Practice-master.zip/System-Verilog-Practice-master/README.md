# System-Verilog-Practice
Repository for system verilog labs from cadence. You should have irun version 15.20-s022 which is a HDL compiler for system verilog(cadence incisive)
